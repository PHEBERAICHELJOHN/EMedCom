package com.example.emedcom;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ColViewUsersActivity extends AppCompatActivity {

    ListView listView;
    SearchView searchView;

    FirebaseDatabase mDatabase;
    DatabaseReference mDb,mDbUSer,mDbUSer2;
    MedData  med;
    ArrayList<String> list;

    //ArrayAdapter <medicinedata> adapt;
    ArrayAdapter<String> adapter;
    private FirebaseAuth firebaseAuth,admin;

    public String[] ab;
    public int i=0;
    public String userDist,tet,userKey,userId_new,userEmail;
    userData usr,usr2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_col_view_users);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
       //not display title in toolbar

        getSupportActionBar().setDisplayShowTitleEnabled(false);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        ab = new String [30];
        listView = (ListView) findViewById(R.id.user_list);

        searchView = (SearchView) findViewById(R.id.searchView);

        list=new ArrayList<>();
        adapter=new ArrayAdapter<String>(this,R.layout.list_user,R.id.userl,list);



        mDatabase = FirebaseDatabase.getInstance();
        mDb = mDatabase.getReference("registration");
        //DatabaseReference zone1Ref = (DatabaseReference) mDb.child();
        usr=new userData();
        usr2=new userData();
        mDb.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds: dataSnapshot.getChildren()){  //dataSnapshot.child(userDist)

                    //Toast.makeText(Buy.this, ""+ds, Toast.LENGTH_SHORT).show();

                    usr=ds.getValue(userData.class);
                    //if(med.getSell().equals("No") ){  //&& med.getFrom().equals(userDist)
                        //Toast.makeText(Buy.this, "  "+med.from, Toast.LENGTH_SHORT).show();
                        //   list.add(med.getMedname().toString()+"  "+med.getQuantity()+"  "+med.getSell().toString());
                        list.add(usr.getEmail().toString()+" \n  "+usr.getUser_type());
                        ab[i]=usr.getEmail();
                        i=i+1;
                    //}
                }
                listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {


                String entry = (String) parent.getItemAtPosition(position);
                Toast.makeText(getApplicationContext(), entry , Toast.LENGTH_LONG).show();

                /*UserRecord userRecord = FirebaseAuth.getInstance().getUserByEmail(ab[position]);
// See the UserRecord reference doc for the contents of userRecord.
                System.out.println("Successfully fetched user data: " + userRecord.getEmail());*/
                FirebaseAuth auth = FirebaseAuth.getInstance();
                FirebaseAuth.AuthStateListener authListener = new FirebaseAuth.AuthStateListener() {
                    @Override
                    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                        FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
                        if ((firebaseUser != null)&&(firebaseUser.getEmail().equals(ab[position]))) {
                             userId_new = firebaseUser.getUid();
                             userEmail = firebaseUser.getEmail();
                             mDatabase.getReference("registration").child(userId_new).child("account_status").setValue("Deactivate").addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    Toast.makeText(getApplicationContext(),"Deactivated",Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                };

                //mDatabase = FirebaseDatabase.getInstance();


                //Intent intent = new Intent(ColViewUsersActivity.this, user_single.class);
                //Get the value of the item you clicked
                //String itemClicked = countries[position];
                //intent.putExtra("details", ab[position] );
                ///intent.putExtra("dist",userDist);
               // startActivity(intent);
            }
        });

        // search view codes
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                adapter.getFilter().filter(newText);
                return false;
            }

        });

    }
}
