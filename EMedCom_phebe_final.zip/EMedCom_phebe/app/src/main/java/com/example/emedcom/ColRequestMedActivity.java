package com.example.emedcom;

import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ColRequestMedActivity extends AppCompatActivity {

    //TextView med_name;
    String com_name,medname,district;
    String request,tet,userKey,type;
    Integer qnt;
    EditText reqst,qnty;
    TextView medicin,comnam;
    Button b1;
    private FirebaseAuth firebaseAuth;
    FirebaseDatabase mDatabase;
    DatabaseReference mDb,mDbUSer,mDbmed2,mDbmed;
    userData usr;
    medicine_save_get getdata;
    public String[] medname_array;
    int i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_col_request_med);

        android.support.v7.widget.Toolbar toolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Request Medicine");
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

     //   Toolbar toolbar = findViewById(R.id.toolbar);
     //   setSupportActionBar(toolbar);

        medicin=(TextView) findViewById(R.id.medname);
        comnam=(TextView) findViewById(R.id.com_name);
        reqst=(EditText) findViewById(R.id.req);
        qnty=(EditText)findViewById(R.id.quantity);


        firebaseAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();
        //mDb = mDatabase.getReference("Collection_accpt_details");

        tet= firebaseAuth.getCurrentUser().getEmail();
        usr=new userData();
        mDbUSer= FirebaseDatabase.getInstance().getReference("registration");
        FirebaseUser user = firebaseAuth.getCurrentUser();
        userKey =FirebaseAuth.getInstance().getCurrentUser().getUid();
        b1=(Button)findViewById(R.id.btnrequest);

        mDbUSer.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for( DataSnapshot ds: dataSnapshot.getChildren()){
                    usr = ds.getValue(userData.class);
                    //userDist = ds.getValue().toString();
                    if(usr.getEmail().equals(tet)){
                        district=usr.getDistrict();
                        type=usr.getUser_type();
                        break;
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        final Spinner medname_spinner = (Spinner) findViewById(R.id.medicine_name);
        final Spinner store_spinner = (Spinner) findViewById(R.id.medicalstore_id_spinner);
        medname_array = new String [70];
        getdata=new medicine_save_get();
        i=0;
        mDbmed=FirebaseDatabase.getInstance().getReference("medicine_details");
        mDbmed.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds:dataSnapshot.getChildren()){
                    getdata=ds.getValue(medicine_save_get.class);
                    medname_array[i]=getdata.getMedname()+getdata.getQnty();
                    i=i+1;
                }

                final ArrayAdapter<String> adapterdis = new ArrayAdapter<String>(ColRequestMedActivity.this, android.R.layout.simple_spinner_item, medname_array);
                adapterdis.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                medname_spinner.setAdapter(adapterdis);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        medname_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View arg1, int position, long id) {

                ((TextView) parent.getChildAt(0)).setTextColor(Color.rgb(76, 156, 210));
                ((TextView) parent.getChildAt(0)).setTextSize(18);
                final String selectedItem = medname_array[position];
                if(selectedItem != null){

                    mDbmed2=FirebaseDatabase.getInstance().getReference("medicine_details");
                    mDbmed2.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            for(DataSnapshot ds:dataSnapshot.getChildren()){
                                getdata=ds.getValue(medicine_save_get.class);
                                String imptest=getdata.getMedname()+getdata.getQnty();
                                if(selectedItem.equals(imptest)){
                                    medicin.setText(getdata.getMedname());
                                    comnam.setText(getdata.getGeneric_name());

                                    Toast.makeText(ColRequestMedActivity.this,getdata.getMedname()+" 0"+imptest, Toast.LENGTH_LONG).show();
                                    break;
                                }
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                    //Toast.makeText(getApplicationContext(), "Hello inside" + " " +selectedItem, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                com_name=comnam.getText().toString();
                medname=medicin.getText().toString();
                request=reqst.getText().toString();
                qnt= Integer.parseInt(qnty.getText().toString());
                String status="saved";

                place_request placereq=new place_request(com_name,medname,userKey,district,request,qnt,status);

                if(type.equals("Collection Centre")) {

                FirebaseDatabase.getInstance().getReference("place_request_details")
                        .child(userKey + medname).setValue(placereq).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_SHORT).show();

                        Intent goIntent = new Intent(getApplicationContext(), CollectionHome.class);
                        goIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(goIntent);
                    }
                });

            }

            else if(type.equals("Charity")){

                FirebaseDatabase.getInstance().getReference("place_request_details_charity").child(district).child(userKey+medname)
                        .setValue(placereq).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Toast.makeText(getApplicationContext(), "Saved charity request", Toast.LENGTH_SHORT).show();

                        Intent goIntent = new Intent(getApplicationContext(), CharityHome.class);
                        goIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(goIntent);

                    }
                });
            }
            }
        });


    }

    private void setSupportActionBar(Toolbar toolbar) {
    }
}
