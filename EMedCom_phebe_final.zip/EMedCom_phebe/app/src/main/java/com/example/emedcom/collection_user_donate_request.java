package com.example.emedcom;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class collection_user_donate_request extends AppCompatActivity {

    ListView listView;
    FirebaseDatabase accDatabase;
    DatabaseReference ref1;
    sell_info_getter sell;
    ArrayList<String> list,list2;
    ArrayAdapter<String> adapter,adapter2;
    private FirebaseAuth firebaseAuth;
    FirebaseDatabase mDatabase;
    DatabaseReference mDb,mDbUSer,mDbmed;
    String userKey,tet,userDist,type,name,ph_num;
    Integer balance;
    userData usr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collection_user_donate_request);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("List of Request");
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        listView=(ListView) findViewById(R.id.acc_med_col);
        list=new ArrayList<>();
        //list2=new ArrayList<>();
        adapter=new ArrayAdapter<String>(this,R.layout.list_med_acc_collection,R.id.med_name_list,list);
        //adapter2=new ArrayAdapter<String>(this,R.layout.list_med_acc_collection,R.id.company_name_list,list2);


        firebaseAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();
        mDb = mDatabase.getReference();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        userKey = user.getUid();
        tet=user.getEmail();
        usr=new userData();
        mDbUSer=FirebaseDatabase.getInstance().getReference("registration");
        mDbUSer.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for( DataSnapshot ds: dataSnapshot.getChildren()){
                    usr = ds.getValue(userData.class);
                    //userDist = ds.getValue().toString();
                    if(usr.getEmail().equals(tet)){
                        userDist = usr.getDistrict();
                        type=usr.getUser_type();
                        name=usr.getName();
                        ph_num=usr.getPhone();
                        balance=usr.getBalance();
                        Toast.makeText(getApplicationContext(), "Hello" + " " +name+ " "+type, Toast.LENGTH_SHORT).show();

                        accDatabase=FirebaseDatabase.getInstance();
                        ref1=accDatabase.getReference("Collection_donate_details").child(userDist);
                        sell=new sell_info_getter();
                        ref1.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                for(DataSnapshot ds:dataSnapshot.getChildren()){
                                    sell=ds.getValue(sell_info_getter.class);
                                    Toast.makeText(getApplicationContext(), " "+sell, Toast.LENGTH_SHORT).show();
                                    if(sell.getStatus().equals("Saved")) {
                                        list.add(sell.getMedname());
                                    }
                                    //list2.add(sell.getCompname());
                                }
                                listView.setAdapter(adapter);
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        break;}
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });





        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String data=(String) parent.getItemAtPosition(position);
                Toast.makeText(getApplicationContext(), " "+data, Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(collection_user_donate_request.this,collection_user_donate_req_view.class);
                intent.putExtra("medname",data);
                intent.putExtra("district",userDist);
                intent.putExtra("mail",tet);
                startActivity(intent);
            }
        });

    }
}
