package com.example.emedcom;

public class place_order_details {

    public String med_name,user_id,company_name,req_user_id,total_quantity,collection_center,status;

    public place_order_details(){

    }

    public place_order_details(String med_name, String user_id, String company_name, String req_user_id, String total_quantity, String collection_center, String status) {
        this.med_name = med_name;
        this.user_id = user_id;
        this.company_name = company_name;
        this.req_user_id = req_user_id;
        this.total_quantity = total_quantity;
        this.collection_center = collection_center;
        this.status = status;
    }
}
