package com.example.emedcom;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class col_req_single extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_col_req_single);

        final String details = getIntent().getStringExtra("details");
        Toast.makeText(getApplicationContext(),"The data is: " + " " +details, Toast.LENGTH_SHORT).show();
    }
}
