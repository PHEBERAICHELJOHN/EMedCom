package com.example.emedcom;

public class place_request {

    String com_name,medname,userid,district,status;
    String request;
    Integer qnt;


    public place_request(){

    }

    public place_request(String com_name, String medname, String userid, String district, String request, Integer qnt,String status) {
        this.com_name = com_name;
        this.medname = medname;
        this.userid = userid;
        this.district = district;
        this.request = request;
        this.qnt = qnt;
        this.status=status;
    }
}
