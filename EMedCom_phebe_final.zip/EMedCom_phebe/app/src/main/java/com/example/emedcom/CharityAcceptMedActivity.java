package com.example.emedcom;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CharityAcceptMedActivity extends AppCompatActivity {

    ListView listView;
    SearchView searchView;

    FirebaseDatabase mDatabase;
    DatabaseReference mDb, mDbUSer, mDbUSer2;
    place_requeat_get med;
    ArrayList<String> list;

    //ArrayAdapter <medicinedata> adapt;
    ArrayAdapter<String> adapter;
    private FirebaseAuth firebaseAuth;

    public String[] ab;
    public int i = 0;
    public String userDist, tet, userKey;
    userData usr;
    Long userbal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_charity_accept_med);


        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        tet = user.getEmail();
        userKey = user.getUid();
        ab = new String[30];
        listView = (ListView) findViewById(R.id.list);

        searchView = (SearchView) findViewById(R.id.searchView);

        list = new ArrayList<>();
        adapter = new ArrayAdapter<String>(this, R.layout.list_buy, R.id.ltext, list);
        mDbUSer = FirebaseDatabase.getInstance().getReference();
        mDbUSer2 = mDbUSer.child("registration").child(userKey).child("district");
        mDbUSer2.keepSynced(true);
        mDbUSer2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                userDist = dataSnapshot.getValue(String.class);

                mDatabase = FirebaseDatabase.getInstance();
                mDb = mDatabase.getReference("place_request_details_charity").child(userDist);
                //DatabaseReference zone1Ref = (DatabaseReference) mDb.child();
                med = new place_requeat_get();

                mDb.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot ds : dataSnapshot.getChildren()) {
                            med = ds.getValue(place_requeat_get.class);

                            String temp1 = med.getMedname();
                            String temp2 = med.getStatus();

                            Toast.makeText(getApplicationContext(), temp1 + temp2, Toast.LENGTH_LONG).show();

                            if ((temp2.equals("Accepted")) && (userKey.equals(med.getUserid()))) {


                                list.add(med.getMedname().toString() + " - " + med.getStatus());
                                // ab[i] = med.getQuantity();
                                // i = i + 1;
                            }
                        }
                        listView.setAdapter(adapter);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}