package com.example.emedcom;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import static com.example.emedcom.RegisterActivity.PReqCode;
import static com.example.emedcom.RegisterActivity.REQUESCODE;

public class placeOrder extends AppCompatActivity {



    private FirebaseAuth firebaseAuth;
    FirebaseDatabase mDatabase;
    DatabaseReference mDb,mDb2,mDb3,mDbUSer;
    MedData  med;
    sell_info_getter med2;
    userData usr;
    TextView t1;
    EditText t2;
    Button b1;
    int test2,qnt,count;
    String userKey,ts,sell_sell,medname,userDist,type,ph_num,name,tet,tt,stat,id,compname,q,w,e,status;
    Integer balance,qntt;
    ImageView ImgUserPhoto;
    Uri pickedImgUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_order);
        t1 = (TextView) findViewById(R.id.textView);
        t2 = (EditText) findViewById(R.id.sell_count);
        b1 = (Button) findViewById(R.id.btn_buy);
        //Viewed Data

        final String details = getIntent().getStringExtra("details");
        final String dist = getIntent().getStringExtra("dist");
        firebaseAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();
        mDb = mDatabase.getReference("Collection_accpt_details").child(dist);
        FirebaseUser user = firebaseAuth.getCurrentUser();
        userKey = FirebaseAuth.getInstance().getCurrentUser().getUid();
        ImgUserPhoto = (ImageView) findViewById(R.id.billimage);
        ImgUserPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (Build.VERSION.SDK_INT >= 22) {

                    checkAndRequestForPermission();
                } else {

                    openGallery();

                }

            }
        });


        med = new MedData();
        med2 = new sell_info_getter();
        mDb.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    med = ds.getValue(MedData.class);
                    if (details.equals(med.getQuantity())) {
                        t1.setText(med.getMedname());
                        compname = med.getCompname();
                        q = med.getCollection_center();
                        w = med.getUsr_id();
                        //e=med.getQuantity();
                        break; //updated now not tested
                    }
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        tet = user.getEmail();
        usr = new userData();
        mDbUSer = FirebaseDatabase.getInstance().getReference("registration");
        mDbUSer.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    usr = ds.getValue(userData.class);
                    //userDist = ds.getValue().toString();
                    if (usr.getEmail().equals(tet)) {
                        userDist = usr.getDistrict();
                        type = usr.getUser_type();
                        name = usr.getName();
                        ph_num = usr.getPhone();
                        balance = usr.getBalance();
                        stat = usr.getAccount_status();
                        id = usr.getId();
                        Toast.makeText(getApplicationContext(), "Hello" + " " + name + " " + type, Toast.LENGTH_SHORT).show();
                        break;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

/*
        mDbUSer=FirebaseDatabase.getInstance().getReference("registration").child(userKey);
        mDbUSer.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //for( DataSnapshot ds: dataSnapshot.getChildren()){
                    usr=dataSnapshot.getValue(userData.class);
               // }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });*/


        //userDist =usr.getDistrict();
        //Buy medicine
        mDb2 = mDatabase.getReference();
        //mDb3=mDatabase.getReference("med_sell_details");


        mDb = mDatabase.getReference("Collection_accpt_details").child(dist);
        mDb.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    med2 = ds.getValue(sell_info_getter.class);

                    if ((med2.getStatus().equals("Accepted")) && (med2.getMedname().equals(t1.getText().toString()))) {
                        count = count + Integer.parseInt(med2.getQuantity());
                        Toast.makeText(getApplicationContext(), count + "testing count" + med2.getMedname(), Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(count>=Integer.parseInt(t2.getText().toString())) {
                    status="Saved";
                    place_order_details pls_order = new place_order_details(
                            t1.getText().toString(),
                            userKey,
                            compname,
                            w,
                            t2.getText().toString(),
                            q,
                            status

                    );
                    Toast.makeText(getApplicationContext(), med.getMedname(), Toast.LENGTH_SHORT).show();
                    String test1 = t2.getText().toString();
                    test2 = Integer.parseInt(test1);
                    Long tsLong = System.currentTimeMillis() / 1000;
                    ts = tsLong.toString();
                    String val = t1.getText().toString();
                    ///Toast.makeText(getApplicationContext(),test1, Toast.LENGTH_SHORT).show();
                    FirebaseDatabase.getInstance().getReference("place_order_details").child(userDist)
                            .child(userKey + val).setValue(pls_order).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {


                                // test= Integer.parseInt(med.getQuantity().toString());
                                qnt = Integer.parseInt(med.getQuantity().toString()) - test2;
                                ///showMessage( String.valueOf(qnt)+"hi" );
                                //Toast.makeText(getApplicationContext(),String.valueOf(qnt)+"hi", Toast.LENGTH_SHORT).show();
                                if (qnt <= 0) {
                                    sell_sell = "Yes";
                                    status = "Soled";
                                } else {
                                    sell_sell = "No";
                                    status = "Accepted";
                                }////*/
                                //user account created successfully
                                //   Toast.makeText(getApplicationContext(), "Hello", Toast.LENGTH_SHORT).show();
                                //showMessage( ts );
                                tt = String.valueOf(qnt);

                                //mDb3=mDatabase.getReference("med_sell_details").child(userKey+med.getMedname());
                                //Toast.makeText(getApplicationContext(), med.getMedname(), Toast.LENGTH_SHORT).show();
                                medname = med.getMedname();
                                String compname = med.getCompname();
                                String frm = med.getFrom();
                                String collection = med.getCollection_center();
                                String exp_date = med.getExp_date();

                                /////////////////////////////////////////////////////////////////////////
                                String temp_data = "abc";

                                //String qnty=quantity.getText().toString();
                                //  sell_sell="Yes";
                                // usr_id=FirebaseAuth.getInstance().getCurrentUser().getUid();
                                sell_info info = new sell_info(
                                        medname,
                                        compname,
                                        temp_data,
                                        frm,
                                        tt,
                                        sell_sell,
                                        userKey,
                                        collection,
                                        exp_date,
                                        status
                                );


                                FirebaseDatabase.getInstance().getReference("Collection_accpt_details")
                                        .child(dist).child(medname + compname)
                                        .setValue(info).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {

                                        if (task.isSuccessful()) {
                                            // showMessage( "Yes i have done it" );
                                            showMessage("Your have placed order for medicines : \n\n " + medname);
                                            showMessage("Dear user, please come and collect at your district collection centre");
                                            // showMessage("Please check your Rewards");
                                            updateUserInfo(pickedImgUri, firebaseAuth.getCurrentUser());

                                        } else {
                                            showMessage("Not Saved");
                                            Toast.makeText(placeOrder.this, task.getException().getMessage(),
                                                    Toast.LENGTH_LONG).show();
                                        }

                                    }
                                });

                                qntt = Integer.parseInt(t2.getText().toString());
                                balance = balance - (qntt * 3);
                                Toast.makeText(getApplicationContext(), "Updated reward" + qntt + " balance" + balance, Toast.LENGTH_LONG).show();
                                final test usr_upd = new test(name, tet, ph_num, type, userDist, balance, stat, id);
                                FirebaseDatabase.getInstance().getReference("registration").child(userKey)
                                        .setValue(usr_upd).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        Intent home = new Intent(getApplicationContext(), Home.class);
                                        home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                        startActivity(home);
                                        Toast.makeText(getApplicationContext(), "Updated reward", Toast.LENGTH_SHORT).show();
                                    }
                                });

                            } else {
                                showMessage("Not Saved");
                                Toast.makeText(placeOrder.this, task.getException().getMessage(),
                                        Toast.LENGTH_LONG).show();
                            }
                        }
                    });

                }

                else{
                    Toast.makeText(placeOrder.this, "Number of medicine is less",
                            Toast.LENGTH_LONG).show();
                }
            }
        });




    }

    private void updateUserInfo(Uri pickedImgUri, final FirebaseUser currentUser) {

        // first we need to upload user photo to firebase storage and get url

            StorageReference mStorage = FirebaseStorage.getInstance().getReference().child("buy_bill_photos").child(userKey);
            final StorageReference imageFilePath = mStorage.child(medname);

            imageFilePath.putFile(pickedImgUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {


                    //Intent intent = new Intent(BillUpload.this, Home.class);
                    //startActivity(intent);

                }
            });

    }


    private void openGallery() {
        //TODO : open gallery intent and wait for user to pick an image !

        Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent,REQUESCODE);



    }

    private void checkAndRequestForPermission() {

        if(ContextCompat.checkSelfPermission(placeOrder.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            if(ActivityCompat.shouldShowRequestPermissionRationale(placeOrder.this, Manifest.permission.READ_EXTERNAL_STORAGE)) {

                Toast.makeText(placeOrder.this,"Please accept for required permission",Toast.LENGTH_SHORT).show();

            }

            else
            {

                ActivityCompat.requestPermissions(placeOrder.this,
                        new String[] {Manifest.permission.READ_EXTERNAL_STORAGE},
                        PReqCode);

            }
        }
        else
            openGallery();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RESULT_OK && requestCode == REQUESCODE && data != null) {

            //the user has successfully picked an image
            //we need to save reference to URI variable

            pickedImgUri = data.getData();
            ImgUserPhoto.setImageURI(pickedImgUri);

        }
    }

    private void showMessage(String message) {

        Toast.makeText(getApplicationContext(), message,Toast.LENGTH_LONG).show();

    }
}
