# mca_project_template
KTU compliant project template for MCA
