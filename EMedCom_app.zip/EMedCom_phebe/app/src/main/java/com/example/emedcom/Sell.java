package com.example.emedcom;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;

public class Sell extends AppCompatActivity {

    EditText quantity,exp_date;
    Button sell,check_exp,check_med;

    TextView med_name, com_name,condition, medicalstore_id;


    Calendar mCurrentDate;
    int day, month, year, j;

    private FirebaseAuth firebaseAuth;
    FirebaseDatabase mDatabase;
    DatabaseReference mDb,mDbUSer,mDbmed,mDbmed2;
    FirebaseAuth.AuthStateListener Authlistener;

    String userDist,usr_id,tet;
    String userKey;
    String medname,frm,qnty,sell_sell,expdate,needed_value;
    String compname,type,ph_num,name,status,medicalstore_id_dat;
    Integer balance,i;
    userData usr;
    medicine_save_get getdata;
    public String[] medname_array;
    public String[] store_id;
    medicine_store_details_get abc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Sell Medicine");
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    //    med_name = (EditText) findViewById(R.id.med_name);

        med_name = (TextView) findViewById(R.id.med_name);
        com_name = (TextView) findViewById(R.id.com_name);
        condition = (TextView) findViewById(R.id.condition);
        quantity = (EditText) findViewById(R.id.quantity);
        exp_date=(EditText) findViewById(R.id.med_expiry) ;
        sell = (Button) findViewById(R.id.btnSell);
        medicalstore_id=(TextView)findViewById(R.id.medicalstore_id);
      //  check_exp=(Button)findViewById(R.id.btnexpdate);
      //  check_med=(Button)findViewById(R.id.btnmedname);


        if (savedInstanceState != null) {
            // Restore value of members from saved state
            med_name.setText( savedInstanceState.getString("Key1"));
            com_name.setText( savedInstanceState.getString("Key2"));
            condition.setText( savedInstanceState.getString("Key3"));
            quantity.setText( Integer.parseInt(savedInstanceState.getString("Key4")));
            //exp_date.setText( savedInstanceState.getString("Key5"));
            medicalstore_id.setText( savedInstanceState.getString("Key6"));

        }

        mCurrentDate = Calendar.getInstance();
        day = mCurrentDate.get(Calendar.DAY_OF_MONTH);
        month = mCurrentDate.get(Calendar.MONTH);
        year = mCurrentDate.get(Calendar.YEAR);
        final Spinner medname_spinner = (Spinner) findViewById(R.id.medicine_name);
        final Spinner store_spinner = (Spinner) findViewById(R.id.medicalstore_id_spinner);
        medname_array = new String [70];
        store_id = new String [70];
        getdata=new medicine_save_get();
        i=0;
        mDbmed=FirebaseDatabase.getInstance().getReference("medicine_details");
        mDbmed.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds:dataSnapshot.getChildren()){
                    getdata=ds.getValue(medicine_save_get.class);
                    medname_array[i]=getdata.getMedname()+getdata.getQnty();
                    i=i+1;
                }

                final ArrayAdapter<String> adapterdis = new ArrayAdapter<String>(Sell.this, android.R.layout.simple_spinner_item, medname_array);
                adapterdis.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                medname_spinner.setAdapter(adapterdis);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        medname_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View arg1, int position, long id) {

                ((TextView) parent.getChildAt(0)).setTextColor(Color.rgb(76, 156, 210));
                ((TextView) parent.getChildAt(0)).setTextSize(18);
                final String selectedItem = medname_array[position];
                if(selectedItem != null){

                    mDbmed2=FirebaseDatabase.getInstance().getReference("medicine_details");
                    mDbmed2.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            for(DataSnapshot ds:dataSnapshot.getChildren()){
                                getdata=ds.getValue(medicine_save_get.class);
                                String imptest=getdata.getMedname()+getdata.getQnty();
                                if(selectedItem.equals(imptest)){
                                    med_name.setText(getdata.getMedname());
                                    com_name.setText(getdata.getGeneric_name());
                                    needed_value=getdata.getQnty().toString();
                                    //quantity.setText(getdata.getQnty());
                                    condition.setText(getdata.getCompname());
                                    Toast.makeText(Sell.this,getdata.getMedname()+" 0"+imptest, Toast.LENGTH_LONG).show();
                                    break;
                                }
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                    //Toast.makeText(getApplicationContext(), "Hello inside" + " " +selectedItem, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });


        month = month+1;

        exp_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendar = Calendar.getInstance();
                int year    = calendar.get(Calendar.YEAR);
                int month   = calendar.get(Calendar.MONTH)+3;
                int day     = calendar.get(Calendar.DAY_OF_MONTH);
                calendar.set(year, month, day);
                DatePickerDialog mDate = new DatePickerDialog(Sell.this, date, year, month, day);
                mDate.getDatePicker().setMinDate(calendar.getTimeInMillis());
                mDate.show();
            }
        });


        j=0;
        firebaseAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();
        mDb = mDatabase.getReference();
        FirebaseUser user = firebaseAuth.getCurrentUser();
         userKey = user.getUid();
         tet=user.getEmail();
         usr=new userData();
        mDbUSer=FirebaseDatabase.getInstance().getReference("registration");
        mDbUSer.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
               for( DataSnapshot ds: dataSnapshot.getChildren()){
                   usr = ds.getValue(userData.class);
                   //userDist = ds.getValue().toString();
                   if(usr.getEmail().equals(tet)){
                    userDist = usr.getDistrict();
                    type=usr.getUser_type();
                    name=usr.getName();
                    ph_num=usr.getPhone();
                    balance=usr.getBalance();
                   Toast.makeText(getApplicationContext(), "Hello" + " " +name+ " "+type, Toast.LENGTH_SHORT).show();

                       FirebaseDatabase.getInstance().getReference("medicalstore").child(userDist).addValueEventListener(new ValueEventListener() {
                           @Override
                           public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                               for(DataSnapshot ds:dataSnapshot.getChildren()){
                                    abc=ds.getValue(medicine_store_details_get.class);
                                   store_id[j]=abc.getId();
                                   j=j+1;
                               }
                               final ArrayAdapter<String> adapterstore = new ArrayAdapter<String>(Sell.this, android.R.layout.simple_spinner_item, store_id);
                               adapterstore.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                               store_spinner.setAdapter(adapterstore);
                           }

                           @Override
                           public void onCancelled(@NonNull DatabaseError databaseError) {

                           }
                       });

                   break;}
               }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        store_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View arg1, int position, long id) {

                ((TextView) parent.getChildAt(0)).setTextColor(Color.rgb(76, 156, 210));
                ((TextView) parent.getChildAt(0)).setTextSize(18);
                final String selectedItem = store_id[position];
                Toast.makeText(Sell.this,selectedItem, Toast.LENGTH_LONG).show();

                medicalstore_id.setText(selectedItem);

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });


  /*      check_exp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                medname = med_name.getText().toString();
                compname = com_name.getText().toString();
                frm = condition.getText().toString();
                qnty = quantity.getText().toString();
                expdate = exp_date.getText().toString();
                medicalstore_id_dat=medicalstore_id.getText().toString();

                if (medname.isEmpty() || compname.isEmpty() || frm.isEmpty() || qnty.isEmpty() || expdate.isEmpty() || medicalstore_id_dat.isEmpty()) {
                    //something goes wrong
                    //all fields need to be filled
                    showMessage("Please verify all fields");

                }
                else{
                    Intent intent = new Intent(Sell.this,OCRcolActivity.class);
                    startActivity(intent);
                }
            }
        });    */


                sell.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        medname = med_name.getText().toString();
                        compname = com_name.getText().toString();
                        frm = condition.getText().toString();
                        qnty = quantity.getText().toString();
                        expdate = exp_date.getText().toString();
                        medicalstore_id_dat=medicalstore_id.getText().toString();

                        if (medname.isEmpty() || compname.isEmpty() || frm.isEmpty() || qnty.isEmpty() || expdate.isEmpty() || medicalstore_id_dat.isEmpty()) {
                            //something goes wrong
                            //all fields need to be filled
                            showMessage("Please verify all fields");

                        } else {
                            sell_sell = "No";
                            status="Saved";
                            usr_id = FirebaseAuth.getInstance().getCurrentUser().getUid();
                            final sell_info info = new sell_info(
                                    medname+needed_value,
                                    compname,
                                    medicalstore_id_dat,
                                    frm,
                                    qnty,
                                    sell_sell,
                                    usr_id,
                                    userDist,
                                    expdate,
                                    status
                            );
                            Long tsLong = System.currentTimeMillis() / 1000;
                            final String ts = tsLong.toString();

                            FirebaseDatabase.getInstance().getReference("user_med_sell_details")
                                    .child(usr_id).child(medname + qnty)
                                    .setValue(info).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                    if (task.isSuccessful()) {

                                        FirebaseDatabase.getInstance().getReference("Collection_accpt_details").child(userDist)
                                                .child(medname+needed_value+ compname).setValue(info).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                Toast.makeText(getApplicationContext(), "Medicine Name : " + medname + "\nGeneric Name : " + compname, Toast.LENGTH_SHORT).show();
                                                showMessage(medname);

                                                Intent uploadbill = new Intent(getApplicationContext(), BillUpload.class);
                                                uploadbill.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                                uploadbill.putExtra("usrDist",userDist);
                                                uploadbill.putExtra("medicine",medname);
                                                uploadbill.putExtra("company",compname);
                                                uploadbill.putExtra("process","Sell");
                                                startActivity(uploadbill);

                                            }
                                        });
                                        /*balance=balance+Integer.parseInt(qnty)*2+1;
                                         final test usr_upd =new test(name,tet,ph_num,type,userDist,balance);
                                        FirebaseDatabase.getInstance().getReference("registration").child(userKey)
                                                .setValue(usr_upd).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        Toast.makeText(getApplicationContext(), "Updated reward", Toast.LENGTH_SHORT).show();
                                                    }
                                                });*/


                                    } else {
                                        showMessage("Not Saved");
                                        Toast.makeText(Sell.this, task.getException().getMessage(),
                                                Toast.LENGTH_LONG).show();
                                    }

                                }
                            });
                        }
                    }
                });

    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putString("KEY1", medname);
        savedInstanceState.putString("KEY2", compname);
        savedInstanceState.putString("KEY3",frm);
        savedInstanceState.putString("KEY4",qnty);
        savedInstanceState.putString("KEY5",expdate);
        savedInstanceState.putString("KEY6",medicalstore_id_dat);

        // Always call the superclass so it can save the view hierarchy state
        super.onSaveInstanceState(savedInstanceState);
    }

    private void showMessage(String message) {

        Toast.makeText(getApplicationContext(), message,Toast.LENGTH_LONG).show();

    }


    final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            view.setMinDate(System.currentTimeMillis() - 1000);
            monthOfYear = monthOfYear+1;
            exp_date.setText(dayOfMonth+"/"+monthOfYear+"/"+year);
        }
    };

}
