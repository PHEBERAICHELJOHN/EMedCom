package com.example.emedcom;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import static com.example.emedcom.RegisterActivity.PReqCode;
import static com.example.emedcom.RegisterActivity.REQUESCODE;

public class BillUpload extends AppCompatActivity {
    String usrDist,compname,medisinename,process;
    ImageView ImgUserPhoto;
    Uri pickedImgUri;
    private FirebaseAuth firebaseAuth;
    String userKey;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill_upload);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Upload Bill");
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent intent=getIntent();
        usrDist=intent.getStringExtra("usrDist");
        medisinename=intent.getStringExtra("medicine");
        compname=intent.getStringExtra("company");
        process=intent.getStringExtra("process");
        b1=(Button) findViewById(R.id.buttonbillsave);
        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        userKey = user.getUid();

        ImgUserPhoto = (ImageView) findViewById(R.id.billimage);

        ImgUserPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(Build.VERSION.SDK_INT >=22) {

                    checkAndRequestForPermission();
                }
                else
                {

                    openGallery();

                }

            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                updateUserInfo( pickedImgUri,firebaseAuth.getCurrentUser());

            }
        });


    }




    private void updateUserInfo(Uri pickedImgUri, final FirebaseUser currentUser) {

        // first we need to upload user photo to firebase storage and get url
        if (process.equals("Sell")) {
            StorageReference mStorage = FirebaseStorage.getInstance().getReference().child("bill_photos").child(userKey);
            final StorageReference imageFilePath = mStorage.child(medisinename);

            imageFilePath.putFile(pickedImgUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {


                    //image uploaded successfully
                    //now we can get image url

                /*imageFilePath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<android.net.Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {

                        //uri contain user image url

                        UserProfileChangeRequest profileUpdate = new UserProfileChangeRequest.Builder()
                                .setDisplayName(medisinename+compname)
                                .setPhotoUri(uri)
                                .build();

                        currentUser.updateProfile(profileUpdate)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {

                                        if(task.isSuccessful()) {*/

                    Intent intent = new Intent(BillUpload.this, Home.class);
                    startActivity(intent);
                                       /* }

                                    }
                                });

                    }
                });*/
                }
            });
        } else if (process.equals("Donate")) {
            StorageReference mStorage = FirebaseStorage.getInstance().getReference().child("don_bill_photos").child(userKey);
            final StorageReference imageFilePath = mStorage.child(medisinename);

            imageFilePath.putFile(pickedImgUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {


                    //image uploaded successfully
                    //now we can get image url

                /*imageFilePath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<android.net.Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {

                        //uri contain user image url

                        UserProfileChangeRequest profileUpdate = new UserProfileChangeRequest.Builder()
                                .setDisplayName(medisinename+compname)
                                .setPhotoUri(uri)
                                .build();

                        currentUser.updateProfile(profileUpdate)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {

                                        if(task.isSuccessful()) {*/

                    Intent intent = new Intent(BillUpload.this, Home.class);
                    startActivity(intent);

                }
            });
        }
    }




    private void openGallery() {
        //TODO : open gallery intent and wait for user to pick an image !

        Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent,REQUESCODE);



    }

    private void checkAndRequestForPermission() {

        if(ContextCompat.checkSelfPermission(BillUpload.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            if(ActivityCompat.shouldShowRequestPermissionRationale(BillUpload.this, Manifest.permission.READ_EXTERNAL_STORAGE)) {

                Toast.makeText(BillUpload.this,"Please accept for required permission",Toast.LENGTH_SHORT).show();

            }

            else
            {

                ActivityCompat.requestPermissions(BillUpload.this,
                        new String[] {Manifest.permission.READ_EXTERNAL_STORAGE},
                        PReqCode);

            }
        }
        else
            openGallery();
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RESULT_OK && requestCode == REQUESCODE && data != null) {

            //the user has successfully picked an image
            //we need to save reference to URI variable

            pickedImgUri = data.getData();
            ImgUserPhoto.setImageURI(pickedImgUri);

        }
    }

}

