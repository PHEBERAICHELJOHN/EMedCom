package com.example.emedcom;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ColViewRequestsActivity extends AppCompatActivity {
    ListView listView;
    SearchView searchView;

    FirebaseDatabase mDatabase;
    DatabaseReference mDb,mDbUSer,mDbUSer2;
    place_requeat_get  req_get;
    ArrayList<String> list;

    //ArrayAdapter <medicinedata> adapt;
    ArrayAdapter<String> adapter;
    private FirebaseAuth firebaseAuth;

    public String[] ab;
    public int i=0;
    public String userDist,tet,userKey,type;
    userData usr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_col_view_requests);

        firebaseAuth = FirebaseAuth.getInstance();

        ab = new String [30];
        listView = (ListView) findViewById(R.id.col_request_view);

        list=new ArrayList<>();
        adapter=new ArrayAdapter<String>(this,R.layout.list_user,R.id.userl,list);

        firebaseAuth = FirebaseAuth.getInstance();
        tet= firebaseAuth.getCurrentUser().getEmail();
        usr=new userData();
        mDbUSer= FirebaseDatabase.getInstance().getReference("registration");
        FirebaseUser user = firebaseAuth.getCurrentUser();
        userKey =FirebaseAuth.getInstance().getCurrentUser().getUid();


        mDbUSer.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for( DataSnapshot ds: dataSnapshot.getChildren()){
                    usr = ds.getValue(userData.class);
                    //userDist = ds.getValue().toString();
                    if(usr.getEmail().equals(tet)){
                        userDist=usr.getDistrict();
                        type=usr.getUser_type();
                        //break;
                        mDatabase = FirebaseDatabase.getInstance();

                        if(type.equals("Collection Centre")){


                            mDb = mDatabase.getReference("place_request_details");
                            //DatabaseReference zone1Ref = (DatabaseReference) mDb.child();
                            req_get=new place_requeat_get();

                            mDb.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    for(DataSnapshot ds: dataSnapshot.getChildren()){  //dataSnapshot.child(userDist)

                                        //Toast.makeText(Buy.this, ""+ds, Toast.LENGTH_SHORT).show();
                                        Toast.makeText(getApplicationContext(),req_get.getUserid(),Toast.LENGTH_LONG).show();

                                        req_get=ds.getValue(place_requeat_get.class);
                                        //if(med.getSell().equals("No") ){  //&& med.getFrom().equals(userDist)
                                        //Toast.makeText(Buy.this, "  "+med.from, Toast.LENGTH_SHORT).show();
                                        //   list.add(med.getMedname().toString()+"  "+med.getQuantity()+"  "+med.getSell().toString());
                                        FirebaseDatabase.getInstance().getReference("registration").child(req_get.getUserid()).child("district")
                                                .addValueEventListener(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                                        Toast.makeText(getApplicationContext(),"Inside reg",Toast.LENGTH_LONG).show();

                                                        String val_test=dataSnapshot.getValue(String.class);
                                                        if(val_test.equals(userDist)){

                                                            Toast.makeText(getApplicationContext(),val_test,Toast.LENGTH_LONG).show();
                                                        }
                                                        else{
                                                            list.add(req_get.getMedname().toString()+" - "+req_get.getQnt());
                                                            ab[i]=req_get.getMedname();
                                                            i=i+1;
                                                            Toast.makeText(getApplicationContext(),"Inside reg"+ab[0],Toast.LENGTH_LONG).show();
                                                        }
                                                        listView.setAdapter(adapter);

                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                                    }
                                                });

                                        //}
                                    }

                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });


                            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                                    String entry = (String) parent.getItemAtPosition(position);
                                    Toast.makeText(getApplicationContext(), entry , Toast.LENGTH_LONG).show();

                                    Intent intent = new Intent(ColViewRequestsActivity.this, colViewRequest_single.class);
                                    //Get the value of the item you clicked
                                    //String itemClicked = countries[position];
                                    intent.putExtra("details", ab[position] );
                                    intent.putExtra("dist",userDist);
                                    startActivity(intent);
                                }
                            });
                        }
                        else if(type.equals("Charity")){

                            mDb = mDatabase.getReference("place_request_details_charity");
                            //DatabaseReference zone1Ref = (DatabaseReference) mDb.child();
                            req_get=new place_requeat_get();

                            mDb.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    for(DataSnapshot ds: dataSnapshot.getChildren()){  //dataSnapshot.child(userDist)

                                        //Toast.makeText(Buy.this, ""+ds, Toast.LENGTH_SHORT).show();

                                        req_get=ds.getValue(place_requeat_get.class);
                                        //if(med.getSell().equals("No") ){  //&& med.getFrom().equals(userDist)
                                        //Toast.makeText(Buy.this, "  "+med.from, Toast.LENGTH_SHORT).show();
                                        //   list.add(med.getMedname().toString()+"  "+med.getQuantity()+"  "+med.getSell().toString());
                                        list.add(req_get.getMedname().toString()+" - "+req_get.getQnt());
                                        ab[i]=req_get.getUserid();
                                        i=i+1;
                                        //}
                                    }
                                    listView.setAdapter(adapter);
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });


                            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                                    String entry = (String) parent.getItemAtPosition(position);
                                    Toast.makeText(getApplicationContext(), entry , Toast.LENGTH_LONG).show();

                                    //Intent intent = new Intent(ColViewUsersActivity.this, user_single.class);
                                    //Get the value of the item you clicked
                                    //String itemClicked = countries[position];
                                    //intent.putExtra("details", ab[position] );
                                    ///intent.putExtra("dist",userDist);
                                    // startActivity(intent);
                                }
                            });

                        }
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

       // Toast.makeText(getApplicationContext(),"page"+type, Toast.LENGTH_LONG).show();
/*

        mDatabase = FirebaseDatabase.getInstance();

        if(type.equals("Collection Centre")){


        mDb = mDatabase.getReference("place_request_details");
        //DatabaseReference zone1Ref = (DatabaseReference) mDb.child();
        req_get=new place_requeat_get();

        mDb.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds: dataSnapshot.getChildren()){  //dataSnapshot.child(userDist)

                    //Toast.makeText(Buy.this, ""+ds, Toast.LENGTH_SHORT).show();

                    req_get=ds.getValue(place_requeat_get.class);
                    //if(med.getSell().equals("No") ){  //&& med.getFrom().equals(userDist)
                    //Toast.makeText(Buy.this, "  "+med.from, Toast.LENGTH_SHORT).show();
                    //   list.add(med.getMedname().toString()+"  "+med.getQuantity()+"  "+med.getSell().toString());
                    list.add(req_get.getMedname().toString()+" - "+req_get.getQnt());
                    ab[i]=req_get.getUserid();
                    i=i+1;
                    //}
                }
                listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                String entry = (String) parent.getItemAtPosition(position);
                Toast.makeText(getApplicationContext(), entry , Toast.LENGTH_LONG).show();

                //Intent intent = new Intent(ColViewUsersActivity.this, user_single.class);
                //Get the value of the item you clicked
                //String itemClicked = countries[position];
                //intent.putExtra("details", ab[position] );
                ///intent.putExtra("dist",userDist);
                // startActivity(intent);
            }
        });
        }
        else if(type.equals("Charity")){

            mDb = mDatabase.getReference("place_request_details_charity");
            //DatabaseReference zone1Ref = (DatabaseReference) mDb.child();
            req_get=new place_requeat_get();

            mDb.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for(DataSnapshot ds: dataSnapshot.getChildren()){  //dataSnapshot.child(userDist)

                        //Toast.makeText(Buy.this, ""+ds, Toast.LENGTH_SHORT).show();

                        req_get=ds.getValue(place_requeat_get.class);
                        //if(med.getSell().equals("No") ){  //&& med.getFrom().equals(userDist)
                        //Toast.makeText(Buy.this, "  "+med.from, Toast.LENGTH_SHORT).show();
                        //   list.add(med.getMedname().toString()+"  "+med.getQuantity()+"  "+med.getSell().toString());
                        list.add(req_get.getMedname().toString()+" - "+req_get.getQnt());
                        ab[i]=req_get.getUserid();
                        i=i+1;
                        //}
                    }
                    listView.setAdapter(adapter);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });


            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                    String entry = (String) parent.getItemAtPosition(position);
                    Toast.makeText(getApplicationContext(), entry , Toast.LENGTH_LONG).show();

                    //Intent intent = new Intent(ColViewUsersActivity.this, user_single.class);
                    //Get the value of the item you clicked
                    //String itemClicked = countries[position];
                    //intent.putExtra("details", ab[position] );
                    ///intent.putExtra("dist",userDist);
                    // startActivity(intent);
                }
            });

        }  */


    }
}
