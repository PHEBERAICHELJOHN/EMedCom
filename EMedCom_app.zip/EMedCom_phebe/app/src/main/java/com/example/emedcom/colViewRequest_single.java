package com.example.emedcom;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class colViewRequest_single extends AppCompatActivity {

    TextView mednam,compnam,amt,weight,usrnam,expdate;
    Button b1;

    private FirebaseAuth firebaseAuth;
    FirebaseDatabase mDatabase;
    DatabaseReference mDb,mDb2,mDb3,mDbUSer;
    MedData  med,med2;
    sell_info_getter get;
    Integer balance,ab4;
    String userKey,usr_id,mednam2;
    place_requeat_get get_dta;

    private StorageReference mImageRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_col_view_request_single);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Accept Request");
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mednam=(TextView)findViewById(R.id.med_name_view);
        compnam=(TextView)findViewById(R.id.company_name_view);
        //weight=(TextView)findViewById(R.id.weight_view);
        amt=(TextView)findViewById(R.id.quantity_view);
        //usrnam=(TextView)findViewById(R.id.user_name_view);
        //expdate=(TextView)findViewById(R.id.exp_date_view);
        b1=(Button)findViewById(R.id.save_view);
        final String dist=getIntent().getStringExtra("dist");
        mednam2=getIntent().getStringExtra("details");
        //String mail=getIntent().getStringExtra("mail");
        final ImageView billPhot = (ImageView) findViewById(R.id.bill_photo);
        Toast.makeText(getApplicationContext(), "fwerewrwerewrwerwrerwerwerewr "+" "+mednam2+" "+dist, Toast.LENGTH_LONG).show();

        firebaseAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();
        mDb = mDatabase.getReference("place_request_details");
        FirebaseUser user = firebaseAuth.getCurrentUser();
        userKey =FirebaseAuth.getInstance().getCurrentUser().getUid();
        get_dta=new place_requeat_get();

        mDb.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    get_dta = ds.getValue(place_requeat_get.class);
                    if (mednam2.equals(get_dta.getMedname())) {
                        mednam.setText(get_dta.getMedname());
                        compnam.setText(get_dta.getCom_name());
                        amt.setText(get_dta.getQnt().toString());
                        usr_id = get_dta.getUserid();
                        break;

                    }
                    Toast.makeText(getApplicationContext(), "inside "+" "+get_dta.getMedname()+" "+dist, Toast.LENGTH_LONG).show();

                }

            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nam1=mednam.getText().toString();
                String nam2=compnam.getText().toString();
                FirebaseDatabase.getInstance().getReference("place_request_details").child(usr_id+get_dta.getMedname()).child("status")
                        .setValue("Accepted").addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Toast.makeText(getApplicationContext(), " Collection_accpt_details updated", Toast.LENGTH_LONG).show();

                        Intent intent = new Intent(getApplicationContext(), CollectionHome.class);
                        startActivity(intent);

                    }
                });
            }
        });




    }
}
