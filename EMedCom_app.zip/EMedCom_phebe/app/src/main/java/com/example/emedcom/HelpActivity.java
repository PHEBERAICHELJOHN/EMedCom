package com.example.emedcom;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

public class HelpActivity extends AppCompatActivity{

    ListView listView;
    SearchView searchView;

    String [] districts = {"Trivandrum  -  9876543210 ", "Kollam  -  8796541203", "Aleppey  -  9658741023",
                            "Pathanamthitta  -  7894560123", "Kottayam  -  7658493201", "Idukki  -  7132014569",
                        "Ernakulam  -  8032104569", "Thrissur  -  80012365478", "Palakkad  -  8332175621", "Malappuram  -  6549873201",
                            "Kozhikode  -  9638527401", "Wayanad  -  9465800321", "Kasarkode  -  9963850247", "Kannur  -  9998745621"};

    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Call Us On");
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listView = (ListView) findViewById(R.id.listView);
        searchView = (SearchView) findViewById(R.id.searchView);

        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,districts);
        listView.setAdapter(adapter);


        // search view codes
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                adapter.getFilter().filter(newText);
                return false;
            }

        });


    }
}
