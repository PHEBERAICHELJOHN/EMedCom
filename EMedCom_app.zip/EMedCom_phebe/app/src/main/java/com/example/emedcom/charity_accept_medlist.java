package com.example.emedcom;

public class charity_accept_medlist {

    String collectioncenterid,
    companyname,
    medicinename,userid,qntity;

    public String getCollectioncenterid() {
        return collectioncenterid;
    }

    public void setCollectioncenterid(String collectioncenterid) {
        this.collectioncenterid = collectioncenterid;
    }

    public String getCompanyname() {
        return companyname;
    }

    public void setCompanyname(String companyname) {
        this.companyname = companyname;
    }

    public String getMedicinename() {
        return medicinename;
    }

    public void setMedicinename(String medicinename) {
        this.medicinename = medicinename;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getQntity() {
        return qntity;
    }

    public void setQntity(String qntity) {
        this.qntity = qntity;
    }
}
