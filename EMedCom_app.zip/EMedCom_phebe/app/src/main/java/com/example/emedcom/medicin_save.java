package com.example.emedcom;

public class medicin_save {
    public String medname, compname,generic_name;
    Integer amount,qnty;

    public medicin_save(){

    }

    public medicin_save(String medname, String compname, String generic_name,Integer amount, Integer qnty) {
        this.medname = medname;
        this.compname = compname;
        this.generic_name=generic_name;
        this.amount = amount;
        this.qnty = qnty;
    }
}
