package com.example.emedcom;

public class charity_req_acc_log {

    String medicinename,companyname,userid,collectioncenterid,qntity;

    public charity_req_acc_log(String medicinename, String companyname, String userid, String collectioncenterid, String qntity) {
        this.medicinename = medicinename;
        this.companyname = companyname;
        this.userid = userid;
        this.collectioncenterid = collectioncenterid;
        this.qntity = qntity;
    }
}
