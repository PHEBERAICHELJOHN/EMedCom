package com.example.emedcom;

public class medicalstore_details_store {

    String name,place,district,id,owner_name;

    public medicalstore_details_store(String name, String owner_name,String id, String district, String place ) {
        this.name = name;
        this.place = place;
        this.district = district;
        this.id = id;
        this.owner_name = owner_name;
    }
}
