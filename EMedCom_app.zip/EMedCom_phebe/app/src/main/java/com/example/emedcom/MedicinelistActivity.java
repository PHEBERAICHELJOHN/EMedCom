package com.example.emedcom;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MedicinelistActivity extends AppCompatActivity {

    ListView listView;
    SearchView searchView;

    FirebaseDatabase mDatabase;
    DatabaseReference mDb, mDbUSer, mDbUSer2;
    medicine_save_get med;
    ArrayList<String> list;

    //ArrayAdapter <medicinedata> adapt;
    ArrayAdapter<String> adapter;
    private FirebaseAuth firebaseAuth;

    public String[] ab;
    public int i = 0;
    public String userDist, tet, userKey;
    userData usr;
    Long userbal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicinelist);


        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser user = firebaseAuth.getCurrentUser();
    //    tet = user.getEmail();
    //    userKey = user.getUid();


        ab = new String[30];
        listView = (ListView) findViewById(R.id.list);

        searchView = (SearchView) findViewById(R.id.searchView);

        list = new ArrayList<>();
        adapter = new ArrayAdapter<String>(this, R.layout.list_user,R.id.userl,list);

        mDatabase = FirebaseDatabase.getInstance();
        mDb = mDatabase.getReference("place_request_details");

        mDb.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds: dataSnapshot.getChildren()){  //dataSnapshot.child(userDist)

                    //Toast.makeText(Buy.this, ""+ds, Toast.LENGTH_SHORT).show();

                    med = ds.getValue(medicine_save_get.class);
                    //if(med.getSell().equals("No") ){  //&& med.getFrom().equals(userDist)
                    //Toast.makeText(Buy.this, "  "+med.from, Toast.LENGTH_SHORT).show();
                    //   list.add(med.getMedname().toString()+"  "+med.getQuantity()+"  "+med.getSell().toString());
                    list.add(med.getGeneric_name()+ " \n "+ med.getAmount());
                    ab[i]=usr.getEmail();
                    i=i+1;
                    //}
                }
                listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        // search view codes
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                adapter.getFilter().filter(newText);
                return false;
            }

        });


    }
}