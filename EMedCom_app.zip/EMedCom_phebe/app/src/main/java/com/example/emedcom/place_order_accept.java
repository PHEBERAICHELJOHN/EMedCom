package com.example.emedcom;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class place_order_accept extends AppCompatActivity {

    ListView listView;
    SearchView searchView;

    FirebaseDatabase mDatabase;
    DatabaseReference mDb,mDbUSer,mDbUSer2;
    place_order_details_getter  place_ord;
    ArrayList<String> list;

    //ArrayAdapter <medicinedata> adapt;
    ArrayAdapter<String> adapter;
    private FirebaseAuth firebaseAuth;

    public String[] ab;
    public int i=0;
    public String userDist,tet,userKey;
    userData usr;
    Long userbal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_order_accept);

        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        tet=user.getEmail();
        userKey = user.getUid();
        ab = new String [30];
        listView = (ListView) findViewById(R.id.list);

        searchView = (SearchView) findViewById(R.id.searchView);

        list=new ArrayList<>();
        adapter=new ArrayAdapter<String>(this,R.layout.list_buy,R.id.ltext,list);

        mDbUSer = FirebaseDatabase.getInstance().getReference();
        mDbUSer2 = mDbUSer.child("registration").child(userKey).child("district");
        mDbUSer2.keepSynced(true);
        mDbUSer2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //usr = ds.getValue(userData.class);
                userDist = dataSnapshot.getValue(String.class);
                Toast.makeText(getApplicationContext(), userDist, Toast.LENGTH_LONG).show();

                mDatabase = FirebaseDatabase.getInstance();
                mDb = mDatabase.getReference("place_order_details").child(userDist);
                place_ord=new place_order_details_getter();
                mDb.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot ds : dataSnapshot.getChildren()) {
                            place_ord = ds.getValue(place_order_details_getter.class);

                            String temp1 = place_ord.getMed_name();
                            String temp2 = place_ord.getTotal_quantity();
                            String temp3=place_ord.getStatus();
                            Toast.makeText(getApplicationContext(), temp1 + temp2, Toast.LENGTH_LONG).show();

                            if (temp3.equals("Saved")) {  //&& med.getFrom().equals(userDist)\

                                list.add(temp1+ " - " + temp2);
                                ab[i] = place_ord.getTotal_quantity();
                                i = i + 1;
                            }
                        }
                        listView.setAdapter(adapter);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {

                        adapter.getFilter().filter(newText);
                        return false;
                    }

                });


                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        /* View parentRow = (View) view.getParent();
         ListView listView = (ListView) parentRow.getParent();
         final int pos = listView.getPositionForView(parentRow);*/

                        // Toast.makeText(getApplicationContext(), ab[position] , Toast.LENGTH_LONG).show();

                        String entry = (String) parent.getItemAtPosition(position);
                        Toast.makeText(getApplicationContext(), entry , Toast.LENGTH_LONG).show();

                        Intent intent = new Intent(place_order_accept.this, place_order_accept_view.class);
                        //Get the value of the item you clicked
                        //String itemClicked = countries[position];
                        intent.putExtra("details", ab[position] );
                        intent.putExtra("dist",userDist);
                        startActivity(intent);


                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
