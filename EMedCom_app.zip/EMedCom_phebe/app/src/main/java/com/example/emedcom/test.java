package com.example.emedcom;

public class test {

    public String name, Email, phone, user_type, district,account_status,id;
    Integer balance;

    public test(){

    }

    public test(String name, String email, String phone, String user_type, String district,Integer balance,String account_status,String id) {
        this.name = name;
        Email = email;
        this.phone = phone;
        this.user_type = user_type;
        this.district = district;
        this.balance=balance;
        this.account_status=account_status;
        this.id=id;
    }
}
