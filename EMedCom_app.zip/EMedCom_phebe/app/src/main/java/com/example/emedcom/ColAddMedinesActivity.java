package com.example.emedcom;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class ColAddMedinesActivity extends AppCompatActivity {

    EditText med_name, com_name, amt, quantity,generic_text;
    Button save;
    private FirebaseAuth firebaseAuth;
    FirebaseDatabase mDatabase;
    String medname, compname,generic;
    Integer amt_unit,qnty;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_col_add_medines);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Add Medicine");
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        med_name = (EditText) findViewById(R.id.med_name);
        com_name = (EditText) findViewById(R.id.com_name);
        amt = (EditText) findViewById(R.id.amount);
        generic_text=(EditText) findViewById(R.id.generic_name);
        quantity = (EditText) findViewById(R.id.quantity);
        save = (Button) findViewById(R.id.btnSave);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (med_name.getText().toString().trim().isEmpty() || com_name.getText().toString().isEmpty() || generic_text.getText().toString().isEmpty() || Integer.parseInt(amt.getText().toString())==0 ||  Integer.parseInt(quantity.getText().toString().trim())==0) {
                    //something goes wrong
                    //all fields need to be filled
                    Toast.makeText(getApplicationContext(), "Please verify all fields", Toast.LENGTH_SHORT).show();


                }
                else {

                    medname = med_name.getText().toString().trim();
                    compname = com_name.getText().toString();
                    generic = generic_text.getText().toString();
                    amt_unit =  Integer.parseInt(amt.getText().toString());
                    qnty = Integer.parseInt(quantity.getText().toString().trim());


                    final medicin_save med_save = new medicin_save(medname,compname,generic,amt_unit,qnty);

                    FirebaseDatabase.getInstance().getReference("medicine_details")
                            .child(medname+qnty).setValue(med_save).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(getApplicationContext(), "saved medicine details", Toast.LENGTH_SHORT).show();

                            Intent goIntent = new Intent(getApplicationContext(), CollectionHome.class);
                            goIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(goIntent);

                        }
                    });
                }



/*
               if (med_name.getText().toString().trim().isEmpty() || com_name.getText().toString().isEmpty() || generic.isEmpty() || Integer.parseInt(amt.getText().toString())==0 ||  Integer.parseInt(quantity.getText().toString().trim())==0) {
                    //something goes wrong
                    //all fields need to be filled
                    Toast.makeText(getApplicationContext(), "Please verify all fields", Toast.LENGTH_SHORT).show();


                }
                else {

                   medname = med_name.getText().toString().trim();
                   compname = com_name.getText().toString();
                   generic = generic_text.getText().toString();
                   amt_unit =  Integer.parseInt(amt.getText().toString());
                   qnty = Integer.parseInt(quantity.getText().toString().trim());


                   final medicin_save med_save = new medicin_save(medname,compname,generic,amt_unit,qnty);

                    FirebaseDatabase.getInstance().getReference("medicine_details")
                            .child(medname+qnty).setValue(med_save).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(getApplicationContext(), "saved medicine details", Toast.LENGTH_SHORT).show();

                            Intent goIntent = new Intent(getApplicationContext(), CollectionHome.class);
                            goIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(goIntent);

                        }
                    });
                }*/
            }
        });


    }

}