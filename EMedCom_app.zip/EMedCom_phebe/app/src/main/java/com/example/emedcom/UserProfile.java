package com.example.emedcom;

public class UserProfile {

    private String Email;
    //private String items;
    private String name;
    private String phone;

    public UserProfile() {

    }

    public UserProfile(String email, String name, String phone) {
        Email = email;
        this.name = name;
        this.phone = phone;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
