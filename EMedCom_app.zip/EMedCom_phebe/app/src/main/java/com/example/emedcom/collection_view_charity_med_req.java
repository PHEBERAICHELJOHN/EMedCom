package com.example.emedcom;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class collection_view_charity_med_req extends AppCompatActivity {

    ListView listView;
    SearchView searchView;

    FirebaseDatabase mDatabase;
    DatabaseReference mDb,mDbUSer,mDbUSer2;
    place_requeat_get  req_med;
    ArrayList<String> list;

    //ArrayAdapter <medicinedata> adapt;
    ArrayAdapter<String> adapter;
    private FirebaseAuth firebaseAuth;

    public String[] ab;
    public String[] ac;
    public int i=0;
    public String userDist,tet,userKey;
    userData usr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collection_view_charity_med_req);





        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        tet=user.getEmail();
        userKey = user.getUid();
        ab = new String[30];
        ac = new String[30];
        listView = (ListView) findViewById(R.id.list);

        searchView = (SearchView) findViewById(R.id.searchView);

        list=new ArrayList<>();
        adapter=new ArrayAdapter<String>(this,R.layout.list_buy,R.id.ltext,list);
        //  adapter=new ArrayAdapter<String>(this,R.layout.activity_buy,R.id.ltext,list);
        //adapter=new ArrayAdapter<medicinedata>(this,R.layout.test,R.id.ltext);
        //userKey =FirebaseAuth.getInstance().getCurrentUser().getUid();
        mDbUSer=FirebaseDatabase.getInstance().getReference();
        mDbUSer2=mDbUSer.child("registration").child(userKey).child("district");
        mDbUSer2.keepSynced(true);
        mDbUSer2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //usr = ds.getValue(userData.class);
                userDist = dataSnapshot.getValue(String.class);
                Toast.makeText(getApplicationContext(), userDist , Toast.LENGTH_LONG).show();


                mDatabase = FirebaseDatabase.getInstance();
                mDb = mDatabase.getReference("place_request_details_charity").child(userDist);
                //DatabaseReference zone1Ref = (DatabaseReference) mDb.child();
                req_med=new place_requeat_get();

                mDb.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for(DataSnapshot ds: dataSnapshot.getChildren()){  //dataSnapshot.child(userDist)

                            //Toast.makeText(Buy.this, ""+ds, Toast.LENGTH_SHORT).show();

                            req_med=ds.getValue(place_requeat_get.class);
                            if(req_med.getStatus().equals("saved") ){
                                //&& med.getFrom().equals(userDist)
                                //Toast.makeText(Buy.this, "  "+med.from, Toast.LENGTH_SHORT).show();
                                //list.add(med.getMedname().toString()+"  "+med.getQuantity()+"  "+med.getSell().toString());
                                list.add(req_med.getMedname());
                                ac[i]=req_med.getMedicine_original_nam();
                                ab[i]=req_med.getUserid();
                                i=i+1;
                            }
                        }
                        listView.setAdapter(adapter);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });




            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Toast.makeText(getApplicationContext(), tet+userKey+userDist , Toast.LENGTH_LONG).show();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                adapter.getFilter().filter(newText);
                return false;
            }

        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String entry = (String) parent.getItemAtPosition(position);


                Intent intent = new Intent(collection_view_charity_med_req.this, collection_view_charity_req_view.class);
                Toast.makeText(getApplicationContext(), ac[position] , Toast.LENGTH_LONG).show();
                intent.putExtra("details", ab[position]);
                intent.putExtra("medname2",ac[position]);
                intent.putExtra("mednam",entry);
                intent.putExtra("dist",userDist);
                startActivity(intent);
            }
        });

    }
}
