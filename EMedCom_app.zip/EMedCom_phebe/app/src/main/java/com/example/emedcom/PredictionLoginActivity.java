package com.example.emedcom;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import javax.microedition.khronos.egl.EGLDisplay;

public class PredictionLoginActivity extends AppCompatActivity {

    EditText predictname, predictpass;
    Button predict;
    private ProgressBar loadingProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prediction_login);

        predictname = (EditText) findViewById(R.id.login_predict);
        predictpass = (EditText) findViewById(R.id.predict_password);
        loadingProgress = (ProgressBar) findViewById(R.id.login_progress);

        predict = (Button) findViewById(R.id.btnPredict);

        loadingProgress.setVisibility(View.INVISIBLE);

        predict.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               String pre_name = predictname.getText().toString();
               String pre_pass = predictpass.getText().toString();

               if(pre_name.isEmpty() || pre_pass.isEmpty()) {

                   Toast.makeText(getApplicationContext(),"please verify both fields", Toast.LENGTH_LONG).show();
                   loadingProgress.setVisibility(View.INVISIBLE);
               }
               else if(pre_name.equals("predict"))  {

                   if(pre_pass.equals("predict")) {

                       Intent intent = new Intent(getApplicationContext(), PredictionActivity.class);
                       startActivity(intent);
                   }

               }
               else if (!pre_name.equals("predict")){

                   if(!pre_pass.equals("predict")) {

                       Toast.makeText(getApplicationContext(),"please enter valid username and password", Toast.LENGTH_LONG).show();
                   }


               }

            }
        });


    }
}
