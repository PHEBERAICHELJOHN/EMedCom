package com.example.emedcom;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class collection_view_charity_req_view extends AppCompatActivity {

    EditText conformed_qnty;
    TextView medname_view,companyname,request,qntity,hand_qntity;
    Button b1;
    place_requeat_get getmeddat;
    sell_info_getter data;
    Integer count;
    String conformed_qnty_get;
    Integer value_given,value_given2;
    private FirebaseAuth firebaseAuth;
    FirebaseDatabase mDatabase;
    DatabaseReference mDb,mDb2,mDb3,mDbUSer;
    String userKey;
    sell_info_getter get_data_charity_med;
    charity_req_acc_log data_log;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collection_view_charity_req_view);

        medname_view=(TextView) findViewById(R.id.med_name);
        companyname=(TextView) findViewById(R.id.gen_name);
        request=(TextView) findViewById(R.id.request);
        qntity=(TextView)findViewById(R.id.qnty_req);
        hand_qntity=(TextView)findViewById(R.id.sel_quantity);
        conformed_qnty=(EditText) findViewById(R.id.accepted_quantity);
        b1=(Button)findViewById(R.id.btnAccept);

        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        userKey = user.getUid();

        final String details = getIntent().getStringExtra("details");
        final String dist = getIntent().getStringExtra("dist");
        final String medname = getIntent().getStringExtra("mednam");
        final String medname2 = getIntent().getStringExtra("medname2");

        Toast.makeText(getApplicationContext(),medname,Toast.LENGTH_LONG).show();

        getmeddat=new place_requeat_get();
        data=new sell_info_getter();
        get_data_charity_med=new sell_info_getter();
        FirebaseDatabase.getInstance().getReference("place_request_details_charity").child(dist).child(details+medname)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        getmeddat=dataSnapshot.getValue(place_requeat_get.class);

                        Toast.makeText(getApplicationContext(),"inside"+medname2,Toast.LENGTH_LONG).show();
                            if(getmeddat!=null){
                                medname_view.setText(getmeddat.getMedname());
                                companyname.setText(getmeddat.getCom_name());
                                request.setText(getmeddat.getRequest());
                                qntity.setText(getmeddat.getQnt().toString());
                                  count=0;

                                  // displaying count of medicines accepted
                                FirebaseDatabase.getInstance().getReference("Collection_donate_details").child(dist)
                                        .addValueEventListener(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                for(DataSnapshot ds: dataSnapshot.getChildren()){
                                                    data=ds.getValue(sell_info_getter.class);
                                                    if((data.getStatus().equals("Accepted"))&&(data.getMedname().equals(medname2))){
                                                        count=count+Integer.parseInt(data.getQuantity());
                                                        Toast.makeText(getApplicationContext(),"inside "+count,Toast.LENGTH_LONG).show();

                                                    }

                                                }hand_qntity.setText(count.toString());
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                            }
                                        });
                            }


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    conformed_qnty_get=conformed_qnty.getText().toString();
                    value_given=Integer.parseInt(conformed_qnty_get);
                    data_log=new charity_req_acc_log(
                            getmeddat.getMedname(),
                            getmeddat.getCom_name(),
                            getmeddat.getUserid(),
                            userKey,
                            conformed_qnty_get

                    );
// count is not corrent .... works like an infinite loop
                    FirebaseDatabase.getInstance().getReference("place_request_details_charity_log").child(dist).child(getmeddat.getUserid()+getmeddat.getMedname())
                            .setValue(data_log).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()) {
                                FirebaseDatabase.getInstance().getReference("Collection_donate_details").child(dist)
                                        .addValueEventListener(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                for( DataSnapshot ds:dataSnapshot.getChildren()){
                                                    get_data_charity_med=ds.getValue(sell_info_getter.class);

//////////////////////////
                                                    Toast.makeText(getApplicationContext(),"done"+medname,Toast.LENGTH_LONG).show();

                                                    if(medname2.equals(get_data_charity_med.getMedname())&&get_data_charity_med.getStatus().equals("Accepted")){

                                                        value_given2=Integer.parseInt(get_data_charity_med.getQuantity());

                                                        /*need to work here the function is not complete
                                                         need to updfate the avilability.*/

                                                        if(value_given2>=value_given){
                                                            value_given2=value_given2-value_given;
                                                            String status;
                                                            if(value_given2==0){
                                                                 status="Donated";
                                                            }
                                                            else
                                                            {
                                                                 status=get_data_charity_med.getStatus();
                                                            }
                                                            sell_info bca_val=new sell_info(
                                                                    get_data_charity_med.getMedname(),
                                                                    get_data_charity_med.getCompname(),
                                                                    get_data_charity_med.getMedicalstore_id(),
                                                                    get_data_charity_med.getFrom(),
                                                                    value_given2.toString(),
                                                                    get_data_charity_med.getSell(),
                                                                    get_data_charity_med.getUsr_id(),
                                                                    get_data_charity_med.getCollection_center(),
                                                                    get_data_charity_med.getExp_date(),
                                                                    status
                                                            );

                                                            FirebaseDatabase.getInstance().getReference("Collection_donate_details").child(dist)
                                                                    .child(get_data_charity_med.getUsr_id()+get_data_charity_med.getMedname())
                                                                    .setValue(bca_val).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                @Override
                                                                public void onComplete(@NonNull Task<Void> task) {
///////////////////////////////////////////////////////////////////
                                                                    FirebaseDatabase.getInstance().getReference("place_request_details_charity").child(dist)
                                                                            .child(getmeddat.getUserid()+getmeddat.getMedname())
                                                                            .child("status").setValue("Accepted").addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                        @Override
                                                                        public void onComplete(@NonNull Task<Void> task) {

                                                                            Toast.makeText(getApplicationContext(),"success",Toast.LENGTH_SHORT).show();

                                                                        }
                                                                    });

                                                                }
                                                            });

                                                            break;
                                                        }
                                                        else{
                                                            value_given=value_given-value_given2;
                                                            value_given2=0;

                                                            String status;
                                                            if(value_given2==0){
                                                                status="Donated";
                                                            }
                                                            else
                                                            {
                                                                status=get_data_charity_med.getStatus();
                                                            }
                                                            sell_info bca_val=new sell_info(
                                                                    get_data_charity_med.getMedname(),
                                                                    get_data_charity_med.getCompname(),
                                                                    get_data_charity_med.getMedicalstore_id(),
                                                                    get_data_charity_med.getFrom(),
                                                                    value_given2.toString(),
                                                                    get_data_charity_med.getSell(),
                                                                    get_data_charity_med.getUsr_id(),
                                                                    get_data_charity_med.getCollection_center(),
                                                                    get_data_charity_med.getExp_date(),
                                                                    status
                                                            );

                                                            FirebaseDatabase.getInstance().getReference("Collection_donate_details").child(dist)
                                                                    .child(get_data_charity_med.getUsr_id()+get_data_charity_med.getMedname())
                                                                    .setValue(bca_val).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                @Override
                                                                public void onComplete(@NonNull Task<Void> task) {
////////////////////////////////////////////////////////////
                                                                    FirebaseDatabase.getInstance().getReference("place_request_details_charity").child(dist)
                                                                            .child(getmeddat.getUserid()+getmeddat.getMedname())
                                                                            .child("status").setValue("Accepted").addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                        @Override
                                                                        public void onComplete(@NonNull Task<Void> task) {

                                                                            Toast.makeText(getApplicationContext(),"success",Toast.LENGTH_SHORT).show();

                                                                        }
                                                                    });


                                                                }
                                                            });
                                                        }

                                                    }
                                                }

                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                            }
                                        });
                            }

                        }
                    });

                    Intent goIntent = new Intent(getApplicationContext(), CollectionHome.class);
                    startActivity(goIntent);

                }

            });


    }
}
