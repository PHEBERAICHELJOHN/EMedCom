package com.example.emedcom;

import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;

public class medicalstore_details extends AppCompatActivity {

    EditText store_name,owner_name,store_id,store_place;
    Button b1;
    String s_name,o_name,s_id,s_place;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicalstore_details);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Add Medical Store");
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        store_name = (EditText) findViewById(R.id.medicalstore_name);
        owner_name=(EditText) findViewById(R.id.medicalstore_owner_name);
        store_id=(EditText)findViewById(R.id.medicalstore_id);
        store_place=(EditText)findViewById(R.id.medicalstore_place);
        b1=(Button) findViewById(R.id.btnstore_save);
        final Spinner spinnerdis = (Spinner) findViewById(R.id.myDistrict);
        //drop down list of different districts
        final String[] districts = new String[] {"Select District",
                "Kollam",
                "Alappuzha",
                "Pathanamthitta",
                "Kottayam",
                "Idukki",
                "Ernakulam",
                "Thrissur",
                "Palakkad",
                "Malappuram",
                "Kozhikode",
                "Wayanad",
                "Kannur",
                "Kasargod"};

        // Initializing an ArrayAdapter
        final ArrayAdapter<String> adapterdis = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, districts);
        adapterdis.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerdis.setAdapter(adapterdis);

        spinnerdis.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View arg1, int position, long id) {

                ((TextView) parent.getChildAt(0)).setTextColor(Color.rgb(76, 156, 210));
                ((TextView) parent.getChildAt(0)).setTextSize(18);
                districts[0] = "Thiruvananthapuram";
                String selectedItem = districts[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });

            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final String spinnerdistrict = (String) spinnerdis.getSelectedItem().toString();
                    s_name = store_name.getText().toString();
                    o_name = owner_name.getText().toString();
                    s_id = store_id.getText().toString();
                    s_place = store_place.getText().toString();

                    if(s_name.isEmpty() || o_name.isEmpty() || s_id.isEmpty() || s_place.isEmpty())
                    {
                        Toast.makeText(getApplicationContext(),"Please verify all fields",Toast.LENGTH_LONG).show();
                    }

                    else {

                        medicalstore_details_store store = new medicalstore_details_store(
                                s_name,
                                o_name,
                                s_id,
                                spinnerdistrict,
                                s_place

                        );

                        FirebaseDatabase.getInstance().getReference("medicalstore").child(spinnerdistrict).child(s_id)
                                .setValue(store).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                Toast.makeText(medicalstore_details.this, "Medical store details added",
                                        Toast.LENGTH_LONG).show();

                                Intent home = new Intent(getApplicationContext(), CollectionHome.class);
                                home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(home);

                            }
                        });
                    }

                }
            });



    }
}
